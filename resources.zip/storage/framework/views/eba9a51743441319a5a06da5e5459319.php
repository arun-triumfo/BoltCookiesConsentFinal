

<?php $__env->startSection('content'); ?>
    <h1>Embed Code</h1>
    <pre><?php echo e($embedCode); ?></pre>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Arun\Laravel\BoltConsent\resources\views/admin/domains/embed_code.blade.php ENDPATH**/ ?>