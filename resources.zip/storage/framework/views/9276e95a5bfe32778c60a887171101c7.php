

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Domains</h5>
                    <a href="<?php echo e(route('admin.domains.create')); ?>" class="btn btn-primary">Add New Domain</a>
                </div>

                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Status</th>
                                    <th>Consent Count</th>
                                    <th>Last Used</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $domains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $domain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($domain->name); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo e($domain->status ? 'success' : 'danger'); ?>">
                                            <?php echo e($domain->status ? 'Active' : 'Inactive'); ?>

                                        </span>
                                    </td>
                                    <td><?php echo e($domain->consent_count); ?></td>
                                    <td><?php echo e($domain->last_used_at ? $domain->last_used_at->format('Y-m-d H:i') : 'Never'); ?></td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <a href="<?php echo e(route('admin.domains.edit', $domain)); ?>" class="btn btn-sm btn-primary">
                                                <i class="fas fa-edit"></i> Edit Domain
                                            </a>
                                            <a href="<?php echo e(route('admin.banner-settings.edit', $domain)); ?>" class="btn btn-sm btn-info">
                                                <i class="fas fa-cog"></i> Banner Settings
                                            </a>
                                            <button type="button" class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#embedCodeModal<?php echo e($domain->id); ?>">
                                                <i class="fas fa-code"></i> Embed Code
                                            </button>
                                            <form action="<?php echo e(route('admin.domains.destroy', $domain)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this domain?')">
                                                    <i class="fas fa-trash"></i> Delete
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>

                                <!-- Embed Code Modal -->
                                <div class="modal fade" id="embedCodeModal<?php echo e($domain->id); ?>" tabindex="-1" aria-labelledby="embedCodeModalLabel<?php echo e($domain->id); ?>" aria-hidden="true">
                                    <div class="modal-dialog modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="embedCodeModalLabel<?php echo e($domain->id); ?>">Embed Code for <?php echo e($domain->name); ?></h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label class="form-label">Copy this code and paste it into your website's HTML:</label>
                                                    <div class="input-group">
                                                        <textarea class="form-control" id="embedCode<?php echo e($domain->id); ?>" rows="6" readonly><?php echo e($domain->getEmbedCode()); ?></textarea>
                                                        <button class="btn btn-primary" onclick="copyEmbedCode(<?php echo e($domain->id); ?>)">
                                                            <i class="fas fa-copy"></i> Copy
                                                        </button>
                                                    </div>
                                                </div>
                                                <div class="alert alert-info">
                                                    <i class="fas fa-info-circle"></i> Place this code just before the closing </body> tag of your website.
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="text-center">No domains found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-4">
                        <?php echo e($domains->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
function copyEmbedCode(domainId) {
    const embedCode = document.getElementById('embedCode' + domainId);
    embedCode.select();
    document.execCommand('copy');
    
    // Show feedback
    const button = event.target.closest('button');
    const originalText = button.innerHTML;
    button.innerHTML = '<i class="fas fa-check"></i> Copied!';
    setTimeout(() => {
        button.innerHTML = originalText;
    }, 2000);
}
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Arun\Laravel\BoltConsent\resources\views/admin/domains/index.blade.php ENDPATH**/ ?>