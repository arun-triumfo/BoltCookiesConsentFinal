<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <style>
        /* Custom styling for the user name button */
        .user-dropdown-btn {
            font-size: 1.1rem;
            font-weight: 600;
            background-color: #f8f9fa;
            border: 1px solid #ccc;
            padding: 10px 20px;
            border-radius: 30px;
            cursor: pointer;
        }

        .user-dropdown-btn:hover {
            background-color: #007bff;
            color: #fff;
            border-color: #007bff;
        }

        /* Tile layout for links */
        .tile-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .tile {
            background-color: #f8f9fa;
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            transition: transform 0.3s ease-in-out;
        }

        .tile:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .tile .tile-link {
            display: block;
            font-size: 1.2rem;
            color: #007bff;
            text-decoration: none;
        }

        .tile .tile-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', 'Laravel')); ?>

                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav me-auto">
                        <?php if(!Request::is('admin/*') && !Request::is('dashboard')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('consent.manage')); ?>">Manage Cookies</a>
                        </li>
                        <?php endif; ?>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ms-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                        <li class="nav-item dropdown">
    <!-- User Name Button -->
    <button class="user-dropdown-btn" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <?php echo e(Auth::user()->name); ?>

    </button>

    <div class="dropdown-menu dropdown-menu-end">
        <!-- Logout Button -->
        <a href="<?php echo e(route('logout')); ?>" class="dropdown-item" 
            onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            Logout
        </a>
        
        <!-- Logout form (hidden) to trigger the logout route) -->
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
    </div>
</li>

                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- Tiles Layout for Links -->
        <?php if(Auth::check()): ?>
            <div class="container tile-container">
                <?php if(Auth::user()): ?>
                    <div class="tile">
                        <a href="<?php echo e(route('admin.dashboard')); ?>" class="tile-link">
                            <strong>Banner Settings</strong>
                        </a>
                    </div>
                    <div class="tile">
                        <a href="<?php echo e(route('admin.categories.index')); ?>" class="tile-link">
                            <strong>Manage Consent Categories</strong>
                        </a>
                    </div>
                    <div class="tile">
                        <a href="<?php echo e(route('admin.consent.logs.index')); ?>" class="tile-link">
                            <strong>View Consent Logs</strong>
                        </a>
                    </div>
                    <div class="tile">
                        <a href="<?php echo e(route('admin.domains.index')); ?>" class="tile-link">
                            <strong>Manage Domains</strong>
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <!-- <?php
            $cookieConsent = request()->cookie('consent_preferences');
            $hasConsent = !empty($cookieConsent);
        ?>
        <?php if(!$hasConsent): ?>
            <?php echo $__env->make('consent.banner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?> -->
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Arun\Laravel\BoltConsent\resources\views/layouts/app.blade.php ENDPATH**/ ?>